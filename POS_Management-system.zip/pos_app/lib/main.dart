import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firebase_options.dart';
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const POSApp());
}

class POSApp extends StatelessWidget {
  const POSApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'POS Management System',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const POSHomePage(),
    );
  }
}

class Product {
  String name;
  double price;
  int stock;

  Product(this.name, this.price, this.stock);
}

class POSHomePage extends StatefulWidget {
  const POSHomePage({super.key});

  @override
  State<POSHomePage> createState() => _POSHomePageState();
}

class _POSHomePageState extends State<POSHomePage> {
  int selectedIndex = 0;
  double totalSales = 0;
  int transactions = 0;
  String paymentMethod = 'Cash';

  final List<Product> products = [
    Product('Sugar', 5000, 20),
    Product('Rice', 4500, 15),
    Product('Cooking Oil', 8000, 10),
    Product('Soap', 3000, 25),
    Product('Bread', 2000, 12),
  ];

  final List<String> customers = [];
  final List<String> salesRecords = [];
  final Map<int, int> cart = {};

  final TextEditingController productName = TextEditingController();
  final TextEditingController productPrice = TextEditingController();
  final TextEditingController productStock = TextEditingController();
  final TextEditingController customerName = TextEditingController();

  double get cartTotal {
    double total = 0;

    cart.forEach((index, quantity) {
      total += products[index].price * quantity;
    });

    return total;
  }

  int get cartItems {
    return cart.values.fold(0, (sum, quantity) => sum + quantity);
  }

  @override
  void dispose() {
    productName.dispose();
    productPrice.dispose();
    productStock.dispose();
    customerName.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      dashboardPage(),
      salesPage(),
      inventoryPage(),
      customersPage(),
      paymentsPage(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'POS MANAGEMENT SYSTEM',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: pages[selectedIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        onDestinationSelected: (index) {
          setState(() {
            selectedIndex = index;
          });
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.dashboard),
            label: 'Dashboard',
          ),
          NavigationDestination(
            icon: Icon(Icons.shopping_cart),
            label: 'Sales',
          ),
          NavigationDestination(
            icon: Icon(Icons.inventory),
            label: 'Inventory',
          ),
          NavigationDestination(
            icon: Icon(Icons.people),
            label: 'Customers',
          ),
          NavigationDestination(
            icon: Icon(Icons.payment),
            label: 'Payments',
          ),
        ],
      ),
    );
  }

  Widget dashboardPage() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          'Business Dashboard',
          style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 20),
        summaryCard(
          'Total Sales',
          'UGX ${totalSales.toStringAsFixed(0)}',
          Icons.attach_money,
          Colors.green,
        ),
        summaryCard(
          'Products',
          '${products.length}',
          Icons.inventory_2,
          Colors.blue,
        ),
        summaryCard(
          'Customers',
          '${customers.length}',
          Icons.people,
          Colors.orange,
        ),
        summaryCard(
          'Transactions',
          '$transactions',
          Icons.receipt_long,
          Colors.purple,
        ),
        const SizedBox(height: 20),
        const Text(
          'Recent Transactions',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        if (salesRecords.isEmpty)
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text('No sales recorded yet.'),
          ),
        ...salesRecords.reversed.take(5).map(
          (record) => ListTile(
            leading: const Icon(Icons.receipt),
            title: Text(record),
          ),
        ),
      ],
    );
  }

  Widget summaryCard(
    String title,
    String value,
    IconData icon,
    Color color,
  ) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: color.withAlpha(35),
          child: Icon(icon, color: color),
        ),
        title: Text(title),
        subtitle: Text(
          value,
          style: const TextStyle(
            fontSize: 21,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget salesPage() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Text(
            'Current Sale: UGX ${cartTotal.toStringAsFixed(0)}',
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        Expanded(
          child: ListView.builder(
            itemCount: products.length,
            itemBuilder: (context, index) {
              final product = products[index];
              final quantity = cart[index] ?? 0;

              return Card(
                margin: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 5,
                ),
                child: ListTile(
                  leading: const Icon(
                    Icons.shopping_bag,
                    color: Colors.blue,
                  ),
                  title: Text(product.name),
                  subtitle: Text(
                    'UGX ${product.price.toStringAsFixed(0)}'
                    ' | Stock: ${product.stock}',
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        onPressed: quantity == 0
                            ? null
                            : () {
                                setState(() {
                                  if (quantity == 1) {
                                    cart.remove(index);
                                  } else {
                                    cart[index] = quantity - 1;
                                  }
                                });
                              },
                        icon: const Icon(Icons.remove_circle_outline),
                      ),
                      Text('$quantity'),
                      IconButton(
                        onPressed: product.stock <= quantity
                            ? null
                            : () {
                                setState(() {
                                  cart[index] = quantity + 1;
                                });
                              },
                        icon: const Icon(Icons.add_circle_outline),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(16),
          child: SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: cart.isEmpty ? null : completeSale,
              icon: const Icon(Icons.payment),
              label: const Text('Complete Sale'),
            ),
          ),
        ),
      ],
    );
  }

  void completeSale() {
    String method = 'Cash';

    showDialog(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, updateDialog) {
            return AlertDialog(
              title: const Text('Complete Payment'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Total: UGX ${cartTotal.toStringAsFixed(0)}',
                  ),
                  const SizedBox(height: 15),
                  DropdownButtonFormField<String>(
                     initialValue: method,
                    decoration: const InputDecoration(
                      labelText: 'Payment Method',
                      border: OutlineInputBorder(),
                    ),
                    items: const [
                      DropdownMenuItem(
                        value: 'Cash',
                        child: Text('Cash'),
                      ),
                      DropdownMenuItem(
                        value: 'Card',
                        child: Text('Credit/Debit Card'),
                      ),
                      DropdownMenuItem(
                        value: 'Mobile Money',
                        child: Text('Mobile Money'),
                      ),
                    ],
                    onChanged: (value) {
                      if (value != null) {
                        updateDialog(() {
                          method = value;
                        });
                      }
                    },
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      final amount = cartTotal;

                      cart.forEach((index, quantity) {
                        products[index].stock -= quantity;
                      });

                      totalSales += amount;
                      transactions++;

                      salesRecords.add(
                        'UGX ${amount.toStringAsFixed(0)} - $method',
                      );

                      cart.clear();
                    });

                    Navigator.pop(dialogContext);

                    ScaffoldMessenger.of(this.context).showSnackBar(
                      const SnackBar(
                        content: Text('Sale completed successfully!'),
                      ),
                    );
                  },
                  child: const Text('Confirm Payment'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Widget inventoryPage() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Inventory',
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
              ),
              ElevatedButton.icon(
                onPressed: addProduct,
                icon: const Icon(Icons.add),
                label: const Text('Add Product'),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView.builder(
            itemCount: products.length,
            itemBuilder: (context, index) {
              final product = products[index];

              return ListTile(
                leading: const Icon(Icons.inventory_2),
                title: Text(product.name),
                subtitle: Text(
                  'Price: UGX ${product.price.toStringAsFixed(0)}'
                  ' | Stock: ${product.stock}',
                ),
                trailing: IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () {
                    setState(() {
                      cart.remove(index);
                      products.removeAt(index);
                    });
                  },
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  void addProduct() {
    productName.clear();
    productPrice.clear();
    productStock.clear();

    showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Add New Product'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: productName,
                  decoration: const InputDecoration(
                    labelText: 'Product Name',
                  ),
                ),
                TextField(
                  controller: productPrice,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Price (UGX)',
                  ),
                ),
                TextField(
                  controller: productStock,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Stock Quantity',
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                final name = productName.text.trim();
                final price = double.tryParse(productPrice.text);
                final stock = int.tryParse(productStock.text);

                if (name.isEmpty ||
                    price == null ||
                    price <= 0 ||
                    stock == null ||
                    stock < 0) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Enter valid product details.'),
                    ),
                  );
                  return;
                }

                setState(() {
                  products.add(Product(name, price, stock));
                });

                Navigator.pop(dialogContext);
              },
              child: const Text('Save Product'),
            ),
          ],
        );
      },
    );
  }

  Widget customersPage() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Customers',
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
              ),
              ElevatedButton.icon(
                onPressed: addCustomer,
                icon: const Icon(Icons.person_add),
                label: const Text('Add Customer'),
              ),
            ],
          ),
        ),
        Expanded(
          child: customers.isEmpty
              ? const Center(child: Text('No customers registered yet.'))
              : ListView.builder(
                  itemCount: customers.length,
                  itemBuilder: (context, index) {
                    return ListTile(
                      leading: const CircleAvatar(
                        child: Icon(Icons.person),
                      ),
                      title: Text(customers[index]),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          setState(() {
                            customers.removeAt(index);
                          });
                        },
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  void addCustomer() {
    customerName.clear();

    showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Register Customer'),
          content: TextField(
            controller: customerName,
            decoration: const InputDecoration(
              labelText: 'Customer Name',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                final name = customerName.text.trim();

                if (name.isEmpty) {
                  return;
                }

                setState(() {
                  customers.add(name);
                });

                Navigator.pop(dialogContext);
              },
              child: const Text('Save Customer'),
            ),
          ],
        );
      },
    );
  }

  Widget paymentsPage() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          'Payments & Transactions',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 20),
        summaryCard(
          'Total Revenue',
          'UGX ${totalSales.toStringAsFixed(0)}',
          Icons.account_balance_wallet,
          Colors.green,
        ),
        summaryCard(
          'Completed Transactions',
          '$transactions',
          Icons.receipt_long,
          Colors.blue,
        ),
        const SizedBox(height: 15),
        const Text(
          'Payment Methods Supported',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const ListTile(
          leading: Icon(Icons.money, color: Colors.green),
          title: Text('Cash'),
        ),
        const ListTile(
          leading: Icon(Icons.credit_card, color: Colors.blue),
          title: Text('Credit/Debit Card'),
        ),
        const ListTile(
          leading: Icon(Icons.phone_android, color: Colors.orange),
          title: Text('Mobile Money'),
        ),
        const Divider(),
        const Text(
          'Transaction History',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        if (salesRecords.isEmpty)
          const Text('No transactions recorded yet.'),
        ...salesRecords.reversed.map(
          (record) => ListTile(
            leading: const Icon(Icons.receipt),
            title: Text(record),
          ),
        ),
      ],
    );
  }
}